function bukaUndangan() {
    document.getElementById('cover').style.display = 'none';
    document.getElementById('mainContent').style.display = 'block';
}

// Countdown Timer
function updateCountdown() {
    const weddingDate = new Date('December 20, 2024 08:00:00').getTime();
    const now = new Date().getTime();
    const gap = weddingDate - now;

    const second = 1000;
    const minute = second * 60;
    const hour = minute * 60;
    const day = hour * 24;

    const d = Math.floor(gap / day);
    const h = Math.floor((gap % day) / hour);
    const m = Math.floor((gap % hour) / minute);
    const s = Math.floor((gap % minute) / second);

    document.getElementById('countdown-timer').innerHTML = `
        <div class="countdown-item">
            <span>${d}</span>
            <p>Hari</p>
        </div>
        <div class="countdown-item">
            <span>${h}</span>
            <p>Jam</p>
        </div>
        <div class="countdown-item">
            <span>${m}</span>
            <p>Menit</p>
        </div>
        <div class="countdown-item">
            <span>${s}</span>
            <p>Detik</p>
        </div>
    `;
}

setInterval(updateCountdown, 1000);

// RSVP Form
document.getElementById('rsvpForm').addEventListener('submit', function(e) {
    e.preventDefault();
    alert('Terima kasih atas konfirmasi kehadiran Anda!');
    this.reset();
}); 